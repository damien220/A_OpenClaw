"""
OpenTelemetry integration — inject trace_id and span_id into log records.

Bridges Python's ``logging`` module with the OpenTelemetry SDK so that
every log record automatically carries ``otel_trace_id``, ``otel_span_id``,
and ``otel_service_name`` attributes (available in formatters and filters).

Requires::

    pip install opentelemetry-api opentelemetry-sdk opentelemetry-instrumentation-logging
    # or: pip install logger_pkg[otel]

Usage::

    from logger_pkg.integrations.opentelemetry import enable_otel

    enable_otel(service_name="my-api", service_version="1.2.3")

If the OpenTelemetry SDK is not installed, :func:`enable_otel` raises
``ImportError`` with the exact pip command. Use :func:`is_available` for
a non-throwing check.
"""

from __future__ import annotations

from typing import Optional


_INSTALL_MSG = (
    "OpenTelemetry packages are required for OTel integration. "
    "Install them with:\n"
    "  pip install opentelemetry-api opentelemetry-sdk "
    "opentelemetry-instrumentation-logging"
)


def is_available() -> bool:
    """Return ``True`` if the OpenTelemetry SDK is installed."""
    try:
        import opentelemetry.sdk  # type: ignore  # noqa: F401
        import opentelemetry.instrumentation.logging  # type: ignore  # noqa: F401
        return True
    except ImportError:
        return False


def enable_otel(
    service_name: str = "unknown-service",
    service_version: str = "",
    set_logging_format: bool = True,
) -> None:
    """Activate OpenTelemetry log record instrumentation.

    After calling this function, every ``logging.LogRecord`` will carry:

    * ``otelTraceID``  — hex trace ID (or ``"0"`` outside a span)
    * ``otelSpanID``   — hex span ID (or ``"0"`` outside a span)
    * ``otelServiceName`` — the configured service name

    These fields are automatically picked up by
    :class:`~logger_pkg.formatters.json_formatter.JSONFormatter`.

    Args:
        service_name: Logical service name reported to the OTel collector.
        service_version: Optional version string.
        set_logging_format: If ``True`` (default), OTel patches the default
                            logging format to include trace/span IDs.

    Raises:
        ImportError: If the required OTel packages are not installed.
    """
    try:
        from opentelemetry import trace  # type: ignore
        from opentelemetry.sdk.resources import Resource  # type: ignore
        from opentelemetry.sdk.trace import TracerProvider  # type: ignore
        from opentelemetry.instrumentation.logging import LoggingInstrumentor  # type: ignore
    except ImportError as exc:
        raise ImportError(_INSTALL_MSG) from exc

    # Set up a TracerProvider if none is configured yet
    current_provider = trace.get_tracer_provider()
    # The default NoOpTracerProvider has no resource attribute
    if not hasattr(current_provider, "resource"):
        resource_attrs = {"service.name": service_name}
        if service_version:
            resource_attrs["service.version"] = service_version
        resource = Resource.create(resource_attrs)
        provider = TracerProvider(resource=resource)
        trace.set_tracer_provider(provider)

    # Instrument the logging module
    LoggingInstrumentor().instrument(set_logging_format=set_logging_format)


def disable_otel() -> None:
    """Deactivate OpenTelemetry log record instrumentation.

    Safe to call even if OTel was never enabled (no-op).
    """
    try:
        from opentelemetry.instrumentation.logging import LoggingInstrumentor  # type: ignore
        LoggingInstrumentor().uninstrument()
    except (ImportError, Exception):
        pass
