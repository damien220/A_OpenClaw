"""
Prometheus integration — emit log-derived metrics.

Registers a ``logging.Handler`` subclass that increments Prometheus
counters on every log record:

* ``log_messages_total{level, logger}`` — count of all log messages
* ``log_errors_total{logger, exception_type}`` — count of ERROR+ records

Requires::

    pip install prometheus_client
    # or: pip install logger_pkg[prometheus]

Usage::

    from logger_pkg.integrations.prometheus import get_metrics_handler

    handler = get_metrics_handler(service_name="my-api")
    logging.getLogger().addHandler(handler)

    # Metrics are exposed via prometheus_client's default registry —
    # serve them however you like (start_http_server, ASGI app, etc.)

If ``prometheus_client`` is not installed, :func:`get_metrics_handler`
raises ``ImportError`` with the exact pip command.
"""

from __future__ import annotations

import logging
from typing import Optional


_INSTALL_MSG = (
    "prometheus_client is required for Prometheus integration. "
    "Install it with:\n"
    "  pip install prometheus_client"
)


def is_available() -> bool:
    """Return ``True`` if ``prometheus_client`` is installed."""
    try:
        import prometheus_client  # type: ignore  # noqa: F401
        return True
    except ImportError:
        return False


class PrometheusMetricsHandler(logging.Handler):
    """Logging handler that increments Prometheus counters.

    This handler does **not** emit log records to any output — it only
    updates metrics.  Attach it alongside your normal handlers.

    Args:
        service_name: Value for the ``service`` label on error counters.
        level: Minimum level to count (default ``NOTSET`` = all).
        registry: Optional ``prometheus_client.CollectorRegistry``.
                  If ``None``, the default global registry is used.
    """

    def __init__(
        self,
        service_name: str = "app",
        level: int = logging.NOTSET,
        registry: Optional[object] = None,
    ) -> None:
        super().__init__(level)

        try:
            from prometheus_client import Counter  # type: ignore
        except ImportError as exc:
            raise ImportError(_INSTALL_MSG) from exc

        kwargs = {}
        if registry is not None:
            kwargs["registry"] = registry

        self._messages_total = Counter(
            "log_messages_total",
            "Total number of log messages",
            ["level", "logger"],
            **kwargs,
        )

        self._errors_total = Counter(
            "log_errors_total",
            "Total number of ERROR+ log messages",
            ["logger", "exception_type", "service"],
            **kwargs,
        )

        self._service_name = service_name

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self._messages_total.labels(
                level=record.levelname,
                logger=record.name,
            ).inc()

            if record.levelno >= logging.ERROR:
                exc_type = ""
                if record.exc_info and record.exc_info[0] is not None:
                    exc_type = record.exc_info[0].__name__
                self._errors_total.labels(
                    logger=record.name,
                    exception_type=exc_type,
                    service=self._service_name,
                ).inc()
        except Exception:
            self.handleError(record)


def get_metrics_handler(
    service_name: str = "app",
    level: int = logging.NOTSET,
    registry: Optional[object] = None,
) -> PrometheusMetricsHandler:
    """Create a :class:`PrometheusMetricsHandler`.

    Args:
        service_name: ``service`` label value for error counters.
        level: Minimum log level to count.
        registry: Optional custom ``CollectorRegistry``.

    Returns:
        A configured handler ready to be added to a logger.

    Raises:
        ImportError: If ``prometheus_client`` is not installed.
    """
    return PrometheusMetricsHandler(
        service_name=service_name,
        level=level,
        registry=registry,
    )
