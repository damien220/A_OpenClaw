"""
Monitoring integrations — optional bridges to observability platforms.

Both integrations are **opt-in** and require external packages that are
NOT bundled with logger_pkg:

    pip install logger_pkg[otel]         # OpenTelemetry
    pip install logger_pkg[prometheus]   # Prometheus

Use :func:`check_monitoring_deps` to verify availability before enabling
an integration, or simply enable it — a clear ``ImportError`` with install
instructions will be raised if the dependency is missing.
"""

from __future__ import annotations

from typing import Dict


def check_monitoring_deps() -> Dict[str, bool]:
    """Check which monitoring dependencies are installed.

    Returns a dict mapping integration name to availability::

        >>> from logger_pkg.integrations import check_monitoring_deps
        >>> check_monitoring_deps()
        {"opentelemetry": False, "prometheus": True}
    """
    results: Dict[str, bool] = {}

    try:
        import opentelemetry  # type: ignore  # noqa: F401
        results["opentelemetry"] = True
    except ImportError:
        results["opentelemetry"] = False

    try:
        import prometheus_client  # type: ignore  # noqa: F401
        results["prometheus"] = True
    except ImportError:
        results["prometheus"] = False

    return results


__all__ = ["check_monitoring_deps"]
