"""
ContextFilter — injects ContextVar fields into every LogRecord.

Attach this filter to any handler (or to the root logger) and every log
record that passes through it will be enriched with the key/value pairs
currently stored in the logger_pkg context store.

Example::

    import logging
    from logger_pkg.context import bind_context
    from logger_pkg.filters.context_filter import ContextFilter

    handler = logging.StreamHandler()
    handler.addFilter(ContextFilter())

    with bind_context(request_id="abc-123"):
        logging.getLogger("myapp").info("Hello")
        # The emitted record will have request_id="abc-123"
"""

from __future__ import annotations

import logging
from typing import Any, Dict


class ContextFilter(logging.Filter):
    """Enrich log records with the current logging context.

    All key/value pairs returned by
    :func:`~logger_pkg.context.get_context` are set as attributes on
    the :class:`logging.LogRecord` before it reaches a formatter or
    handler.

    Args:
        prefix: Optional string prepended to every context key name to
                avoid collisions with built-in LogRecord attributes.
                E.g. ``prefix="ctx_"`` → ``ctx_request_id``.
    """

    def __init__(self, name: str = "", prefix: str = "") -> None:
        super().__init__(name)
        self._prefix = prefix

    def filter(self, record: logging.LogRecord) -> bool:
        # Import here to avoid circular import at module load time
        from logger_pkg.context import get_context

        ctx: Dict[str, Any] = get_context()
        for key, value in ctx.items():
            setattr(record, self._prefix + key, value)
        return True
