"""
SamplingFilter — probabilistic rate-limiting for high-frequency log records.

Useful for reducing noise from DEBUG (or INFO) spam in production without
losing all visibility.

Only records at or below *max_level* are subject to sampling; records at
higher severity levels always pass through.

Example — keep 10 % of DEBUG records::

    from logger_pkg.filters.sampling_filter import SamplingFilter

    handler.addFilter(SamplingFilter(rate=0.1, max_level=logging.DEBUG))

Thread safety: :func:`random.random` is thread-safe in CPython (the GIL
protects the global PRNG state).  For truly reproducible behaviour in tests,
use a seeded :class:`random.Random` instance via the *rng* argument.
"""

from __future__ import annotations

import logging
import random
from typing import Optional


class SamplingFilter(logging.Filter):
    """Drop a fraction of log records probabilistically.

    Args:
        rate: Fraction of records to **keep** in the range [0.0, 1.0].
              ``1.0`` keeps all records (default); ``0.0`` drops all.
        max_level: Maximum level integer subject to sampling.  Records
                   **above** this level always pass.  Defaults to
                   ``logging.DEBUG``.
        rng: Optional :class:`random.Random` instance (useful for testing
             with a fixed seed).  If ``None`` the module-level ``random``
             functions are used.
    """

    def __init__(
        self,
        name: str = "",
        rate: float = 1.0,
        max_level: int = logging.DEBUG,
        rng: Optional[random.Random] = None,
    ) -> None:
        super().__init__(name)

        if not 0.0 <= rate <= 1.0:
            raise ValueError(f"rate must be in [0.0, 1.0], got {rate!r}")

        self._rate = rate
        self._max_level = max_level
        self._rng = rng

    @property
    def rate(self) -> float:
        return self._rate

    @rate.setter
    def rate(self, value: float) -> None:
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"rate must be in [0.0, 1.0], got {value!r}")
        self._rate = value

    def filter(self, record: logging.LogRecord) -> bool:
        # High-severity records always pass through
        if record.levelno > self._max_level:
            return True

        # Fast path: keep all or drop all
        if self._rate >= 1.0:
            return True
        if self._rate <= 0.0:
            return False

        rand = self._rng.random() if self._rng is not None else random.random()
        return rand < self._rate
