"""
PIIFilter — regex-based scrubbing of personally-identifiable information.

The filter rewrites ``record.msg`` and ``record.args`` in-place, replacing
matches with a configurable placeholder string.

Built-in patterns (enabled by default):
  * Email addresses
  * Credit card numbers (Luhn-format, 13-19 digits with optional separators)
  * US Social Security Numbers (XXX-XX-XXXX)
  * IPv4 addresses
  * Bearer / API tokens (``Bearer <token>``, ``token=<value>``, etc.)

Additional patterns can be supplied at construction time.

.. warning::
   This filter modifies records **in place** which means the original
   message text is permanently changed for all downstream handlers.
   If you need the raw message elsewhere, attach the filter only to the
   handler(s) that write to external / sensitive targets.
"""

from __future__ import annotations

import logging
import re
from typing import List, Optional, Sequence


# ---------------------------------------------------------------------------
# Built-in PII patterns
# ---------------------------------------------------------------------------

_BUILTIN_PATTERNS: List[tuple[str, str]] = [
    # Email
    (
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
        "[EMAIL]",
    ),
    # Credit card (13-19 digits, optional spaces or dashes every 4)
    (
        r"\b(?:\d[ \-]?){12,18}\d\b",
        "[CC_NUMBER]",
    ),
    # US Social Security Number
    (
        r"\b\d{3}-\d{2}-\d{4}\b",
        "[SSN]",
    ),
    # IPv4 address
    (
        r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        "[IPv4]",
    ),
    # Bearer token
    (
        r"(?i)(bearer\s+)[A-Za-z0-9\-._~+/]+=*",
        r"\1[TOKEN]",
    ),
    # Generic key=value secrets (password, secret, token, api_key, apikey)
    (
        r"(?i)((?:password|passwd|secret|token|api_key|apikey)\s*[=:]\s*)\S+",
        r"\1[REDACTED]",
    ),
]


# ---------------------------------------------------------------------------
# Filter
# ---------------------------------------------------------------------------

class PIIFilter(logging.Filter):
    """Scrub PII and secrets from log messages using regular expressions.

    Args:
        extra_patterns: Additional ``(pattern, replacement)`` tuples to
                        apply **after** the built-in patterns.
        disable_builtins: If ``True``, only *extra_patterns* are applied.
        placeholder: Default replacement string (used when the built-in
                     replacement string is plain, not a back-reference).
                     Not used for patterns that have their own replacement.
    """

    def __init__(
        self,
        name: str = "",
        extra_patterns: Optional[Sequence[tuple[str, str]]] = None,
        disable_builtins: bool = False,
        placeholder: str = "[REDACTED]",
    ) -> None:
        super().__init__(name)
        self._placeholder = placeholder

        source = [] if disable_builtins else list(_BUILTIN_PATTERNS)
        if extra_patterns:
            source.extend(extra_patterns)

        self._rules: List[tuple[re.Pattern[str], str]] = [
            (re.compile(pat), repl) for pat, repl in source
        ]

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._scrub(str(record.msg))

        if record.args:
            if isinstance(record.args, dict):
                record.args = {k: self._scrub(str(v)) for k, v in record.args.items()}
            elif isinstance(record.args, tuple):
                record.args = tuple(self._scrub(str(a)) for a in record.args)

        return True

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _scrub(self, text: str) -> str:
        for pattern, replacement in self._rules:
            text = pattern.sub(replacement, text)
        return text
