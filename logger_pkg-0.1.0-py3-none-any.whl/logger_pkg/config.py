"""
LoggerConfig — central configuration dataclass for logger_pkg.

Supports three loading strategies (applied in order, later values win):
  1. Hardcoded defaults
  2. Environment variables (LOG_LEVEL, LOG_FORMAT, LOG_FILE, …)
  3. YAML or JSON config file passed explicitly
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
LogFormat = Literal["json", "console"]


# ---------------------------------------------------------------------------
# Dataclass
# ---------------------------------------------------------------------------

@dataclass
class LoggerConfig:
    # Core
    level: str = "INFO"
    format: LogFormat = "console"

    # Console handler
    console_enabled: bool = True
    console_stream: str = "stderr"          # "stdout" or "stderr"

    # File handler
    file_enabled: bool = False
    file_path: str = "app.log"
    file_rotation: Literal["size", "time", "none"] = "size"
    file_max_bytes: int = 10 * 1024 * 1024  # 10 MB
    file_backup_count: int = 5
    file_when: str = "midnight"             # for TimedRotatingFileHandler
    file_interval: int = 1
    file_gzip: bool = True                  # compress rotated files

    # Async queue
    async_queue_enabled: bool = True
    async_queue_size: int = 10_000          # 0 = unbounded

    # PII filter
    pii_filter_enabled: bool = False
    pii_patterns: List[str] = field(default_factory=list)  # extra regex patterns

    # Sampling filter
    sampling_filter_enabled: bool = False
    sampling_rate: float = 1.0              # 1.0 = keep all, 0.1 = keep 10 %
    sampling_level: str = "DEBUG"           # only sample at this level and below

    # Database handler (Phase 2 — backed by db_accessor)
    db_enabled: bool = False
    db_type: str = "sqlite"                          # sqlite, postgres, mysql, mongodb, redis
    db_connection_details: Dict[str, Any] = field(default_factory=dict)
    db_table: str = "log_records"                    # table / collection name
    db_level: str = "WARNING"                        # min level persisted to DB
    db_batch_size: int = 100
    db_flush_interval: float = 2.0
    db_queue_size: int = 10_000
    db_retry_attempts: int = 3

    # CloudWatch handler (Phase 3 — requires watchtower + boto3)
    cloudwatch_enabled: bool = False
    cloudwatch_log_group: str = "app-logs"
    cloudwatch_stream_name: str = "{strftime:%Y/%m/%d}"
    cloudwatch_region: str = "us-east-1"
    cloudwatch_send_interval: int = 5
    cloudwatch_retention_days: Optional[int] = None
    cloudwatch_level: str = "INFO"

    # Loki handler (Phase 3 — zero-dep stdlib, optional python-logging-loki)
    loki_enabled: bool = False
    loki_url: str = ""
    loki_labels: Dict[str, str] = field(default_factory=dict)
    loki_auth_user: str = ""
    loki_auth_password: str = ""
    loki_level: str = "INFO"

    # Elasticsearch handler (Phase 3 — requires elasticsearch>=8.0)
    elasticsearch_enabled: bool = False
    elasticsearch_hosts: List[str] = field(default_factory=list)
    elasticsearch_index_prefix: str = "app-logs"
    elasticsearch_cloud_id: str = ""
    elasticsearch_api_key: str = ""
    elasticsearch_basic_auth_user: str = ""
    elasticsearch_basic_auth_password: str = ""
    elasticsearch_batch_size: int = 100
    elasticsearch_flush_interval: float = 5.0
    elasticsearch_level: str = "INFO"

    # Sentry integration (Phase 3 — requires sentry-sdk>=2.0)
    sentry_enabled: bool = False
    sentry_dsn: str = ""
    sentry_environment: str = "production"
    sentry_release: str = ""
    sentry_breadcrumb_level: str = "INFO"
    sentry_event_level: str = "ERROR"
    sentry_traces_sample_rate: float = 0.0

    # OpenTelemetry integration (Phase 4 — requires opentelemetry-* packages)
    otel_enabled: bool = False
    otel_service_name: str = "unknown-service"
    otel_service_version: str = ""

    # Prometheus integration (Phase 4 — requires prometheus_client)
    prometheus_enabled: bool = False
    prometheus_service_name: str = "app"

    # Extra fields injected into every JSON record
    extra_fields: Dict[str, Any] = field(default_factory=dict)

    # Propagation
    propagate: bool = False


# ---------------------------------------------------------------------------
# Environment variable loader
# ---------------------------------------------------------------------------

_ENV_BOOL_TRUE = {"1", "true", "yes", "on"}


def _env_bool(key: str, default: bool) -> bool:
    val = os.environ.get(key)
    if val is None:
        return default
    return val.strip().lower() in _ENV_BOOL_TRUE


def _env_int(key: str, default: int) -> int:
    val = os.environ.get(key)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        return default


def _env_float(key: str, default: float) -> float:
    val = os.environ.get(key)
    if val is None:
        return default
    try:
        return float(val)
    except ValueError:
        return default


def load_from_env(base: Optional[LoggerConfig] = None) -> LoggerConfig:
    """Return a LoggerConfig populated from environment variables.

    Variables (all optional, prefixed with ``LOG_``):

    =====================  ==================  ==============================
    Variable               Default             Description
    =====================  ==================  ==============================
    LOG_LEVEL              INFO                Logging level
    LOG_FORMAT             console             ``json`` or ``console``
    LOG_CONSOLE            true                Enable console handler
    LOG_CONSOLE_STREAM     stderr              ``stdout`` or ``stderr``
    LOG_FILE               false               Enable file handler
    LOG_FILE_PATH          app.log             Log file path
    LOG_FILE_ROTATION      size                ``size``, ``time``, or ``none``
    LOG_FILE_MAX_BYTES     10485760            Max size before rotation
    LOG_FILE_BACKUP_COUNT  5                   Number of backup files
    LOG_FILE_WHEN          midnight            Rotation schedule (time mode)
    LOG_FILE_INTERVAL      1                   Rotation interval (time mode)
    LOG_FILE_GZIP          true                Compress rotated files
    LOG_ASYNC_QUEUE        true                Wrap handlers in async queue
    LOG_ASYNC_QUEUE_SIZE   10000               Queue capacity (0 = unbounded)
    LOG_PII_FILTER         false               Enable PII scrubbing filter
    LOG_SAMPLING           false               Enable sampling filter
    LOG_SAMPLING_RATE      1.0                 Fraction of records to keep
    LOG_SAMPLING_LEVEL     DEBUG               Max level subject to sampling
    LOG_PROPAGATE          false               Propagate to root logger
    LOG_DB                 false               Enable database handler
    LOG_DB_TYPE            sqlite              db_accessor backend name
    LOG_DB_TABLE           log_records         Table / collection name
    LOG_DB_LEVEL           WARNING             Min level persisted to DB
    LOG_DB_BATCH_SIZE      100                 Records per write batch
    LOG_DB_FLUSH_INTERVAL  2.0                 Seconds between flushes
    LOG_DB_QUEUE_SIZE      10000               In-memory buffer capacity
    LOG_DB_RETRY           3                   Write retry attempts
    LOG_CLOUDWATCH         false               Enable CloudWatch handler
    LOG_CW_LOG_GROUP       app-logs            CloudWatch log group
    LOG_CW_STREAM          {strftime:%Y/%m/%d} CloudWatch stream name
    LOG_CW_REGION          us-east-1           AWS region
    LOG_CW_INTERVAL        5                   Send interval (seconds)
    LOG_CW_RETENTION       (none)              Retention days
    LOG_CW_LEVEL           INFO                Min level for CloudWatch
    LOG_LOKI               false               Enable Loki handler
    LOG_LOKI_URL           (none)              Loki push URL
    LOG_LOKI_AUTH_USER     (none)              Loki basic auth user
    LOG_LOKI_AUTH_PASS     (none)              Loki basic auth password
    LOG_LOKI_LEVEL         INFO                Min level for Loki
    LOG_ELASTICSEARCH      false               Enable Elasticsearch handler
    LOG_ES_HOSTS           (none)              Comma-separated ES host URLs
    LOG_ES_INDEX_PREFIX    app-logs            Daily index prefix
    LOG_ES_CLOUD_ID        (none)              Elastic Cloud ID
    LOG_ES_API_KEY         (none)              ES API key
    LOG_ES_AUTH_USER       (none)              ES basic auth user
    LOG_ES_AUTH_PASS       (none)              ES basic auth password
    LOG_ES_BATCH_SIZE      100                 Docs per bulk request
    LOG_ES_FLUSH_INTERVAL  5.0                 Seconds between flushes
    LOG_ES_LEVEL           INFO                Min level for ES
    LOG_SENTRY             false               Enable Sentry integration
    LOG_SENTRY_DSN         (none)              Sentry DSN
    LOG_SENTRY_ENV         production          Sentry environment
    LOG_SENTRY_RELEASE     (none)              Sentry release
    LOG_SENTRY_BC_LEVEL    INFO                Breadcrumb level
    LOG_SENTRY_EV_LEVEL    ERROR               Event level
    LOG_SENTRY_TRACES_RATE 0.0                 Traces sample rate
    LOG_OTEL               false               Enable OpenTelemetry bridge
    LOG_OTEL_SERVICE_NAME  unknown-service     OTel service name
    LOG_OTEL_SERVICE_VER   (empty)             OTel service version
    LOG_PROMETHEUS         false               Enable Prometheus metrics
    LOG_PROM_SERVICE_NAME  app                 Prometheus service label
    =====================  ==================  ==============================

    For ``db_connection_details``, set individual keys via env vars:

    ===========================  ========================================
    Variable                     Description
    ===========================  ========================================
    LOG_DB_FILE                  SQLite file path (sets ``file`` key)
    LOG_DB_HOST                  Database host
    LOG_DB_PORT                  Database port
    LOG_DB_NAME                  Database name (``dbname`` / ``database``)
    LOG_DB_USER                  Database user
    LOG_DB_PASSWORD              Database password
    ===========================  ========================================
    """
    cfg = base or LoggerConfig()

    cfg.level = os.environ.get("LOG_LEVEL", cfg.level).upper()
    raw_format = os.environ.get("LOG_FORMAT", cfg.format)
    cfg.format = raw_format if raw_format in ("json", "console") else cfg.format  # type: ignore[assignment]

    cfg.console_enabled = _env_bool("LOG_CONSOLE", cfg.console_enabled)
    cfg.console_stream = os.environ.get("LOG_CONSOLE_STREAM", cfg.console_stream)

    cfg.file_enabled = _env_bool("LOG_FILE", cfg.file_enabled)
    cfg.file_path = os.environ.get("LOG_FILE_PATH", cfg.file_path)
    raw_rotation = os.environ.get("LOG_FILE_ROTATION", cfg.file_rotation)
    cfg.file_rotation = raw_rotation if raw_rotation in ("size", "time", "none") else cfg.file_rotation  # type: ignore[assignment]
    cfg.file_max_bytes = _env_int("LOG_FILE_MAX_BYTES", cfg.file_max_bytes)
    cfg.file_backup_count = _env_int("LOG_FILE_BACKUP_COUNT", cfg.file_backup_count)
    cfg.file_when = os.environ.get("LOG_FILE_WHEN", cfg.file_when)
    cfg.file_interval = _env_int("LOG_FILE_INTERVAL", cfg.file_interval)
    cfg.file_gzip = _env_bool("LOG_FILE_GZIP", cfg.file_gzip)

    cfg.async_queue_enabled = _env_bool("LOG_ASYNC_QUEUE", cfg.async_queue_enabled)
    cfg.async_queue_size = _env_int("LOG_ASYNC_QUEUE_SIZE", cfg.async_queue_size)

    cfg.pii_filter_enabled = _env_bool("LOG_PII_FILTER", cfg.pii_filter_enabled)

    cfg.sampling_filter_enabled = _env_bool("LOG_SAMPLING", cfg.sampling_filter_enabled)
    cfg.sampling_rate = _env_float("LOG_SAMPLING_RATE", cfg.sampling_rate)
    cfg.sampling_level = os.environ.get("LOG_SAMPLING_LEVEL", cfg.sampling_level).upper()

    cfg.propagate = _env_bool("LOG_PROPAGATE", cfg.propagate)

    # Database handler
    cfg.db_enabled = _env_bool("LOG_DB", cfg.db_enabled)
    cfg.db_type = os.environ.get("LOG_DB_TYPE", cfg.db_type).lower()
    cfg.db_table = os.environ.get("LOG_DB_TABLE", cfg.db_table)
    cfg.db_level = os.environ.get("LOG_DB_LEVEL", cfg.db_level).upper()
    cfg.db_batch_size = _env_int("LOG_DB_BATCH_SIZE", cfg.db_batch_size)
    cfg.db_flush_interval = _env_float("LOG_DB_FLUSH_INTERVAL", cfg.db_flush_interval)
    cfg.db_queue_size = _env_int("LOG_DB_QUEUE_SIZE", cfg.db_queue_size)
    cfg.db_retry_attempts = _env_int("LOG_DB_RETRY", cfg.db_retry_attempts)

    # Build connection_details from individual env vars
    conn = dict(cfg.db_connection_details)  # preserve any pre-set values
    if os.environ.get("LOG_DB_FILE"):
        conn["file"] = os.environ["LOG_DB_FILE"]
    if os.environ.get("LOG_DB_HOST"):
        conn["host"] = os.environ["LOG_DB_HOST"]
    if os.environ.get("LOG_DB_PORT"):
        conn["port"] = int(os.environ["LOG_DB_PORT"])
    if os.environ.get("LOG_DB_NAME"):
        # Postgres uses "dbname", others use "database"
        key = "dbname" if cfg.db_type == "postgres" else "database"
        conn[key] = os.environ["LOG_DB_NAME"]
    if os.environ.get("LOG_DB_USER"):
        conn["user"] = os.environ["LOG_DB_USER"]
    if os.environ.get("LOG_DB_PASSWORD"):
        conn["password"] = os.environ["LOG_DB_PASSWORD"]
    if conn:
        cfg.db_connection_details = conn

    # CloudWatch handler
    cfg.cloudwatch_enabled = _env_bool("LOG_CLOUDWATCH", cfg.cloudwatch_enabled)
    cfg.cloudwatch_log_group = os.environ.get("LOG_CW_LOG_GROUP", cfg.cloudwatch_log_group)
    cfg.cloudwatch_stream_name = os.environ.get("LOG_CW_STREAM", cfg.cloudwatch_stream_name)
    cfg.cloudwatch_region = os.environ.get("LOG_CW_REGION", cfg.cloudwatch_region)
    cfg.cloudwatch_send_interval = _env_int("LOG_CW_INTERVAL", cfg.cloudwatch_send_interval)
    cw_retention = os.environ.get("LOG_CW_RETENTION")
    if cw_retention is not None:
        cfg.cloudwatch_retention_days = int(cw_retention) if cw_retention else None
    cfg.cloudwatch_level = os.environ.get("LOG_CW_LEVEL", cfg.cloudwatch_level).upper()

    # Loki handler
    cfg.loki_enabled = _env_bool("LOG_LOKI", cfg.loki_enabled)
    cfg.loki_url = os.environ.get("LOG_LOKI_URL", cfg.loki_url)
    cfg.loki_auth_user = os.environ.get("LOG_LOKI_AUTH_USER", cfg.loki_auth_user)
    cfg.loki_auth_password = os.environ.get("LOG_LOKI_AUTH_PASS", cfg.loki_auth_password)
    cfg.loki_level = os.environ.get("LOG_LOKI_LEVEL", cfg.loki_level).upper()
    # Loki labels from env: LOG_LOKI_LABEL_app=myapp → {"app": "myapp"}
    for key, value in os.environ.items():
        if key.startswith("LOG_LOKI_LABEL_"):
            label_name = key[len("LOG_LOKI_LABEL_"):].lower()
            cfg.loki_labels[label_name] = value

    # Elasticsearch handler
    cfg.elasticsearch_enabled = _env_bool("LOG_ELASTICSEARCH", cfg.elasticsearch_enabled)
    es_hosts = os.environ.get("LOG_ES_HOSTS")
    if es_hosts:
        cfg.elasticsearch_hosts = [h.strip() for h in es_hosts.split(",") if h.strip()]
    cfg.elasticsearch_index_prefix = os.environ.get("LOG_ES_INDEX_PREFIX", cfg.elasticsearch_index_prefix)
    cfg.elasticsearch_cloud_id = os.environ.get("LOG_ES_CLOUD_ID", cfg.elasticsearch_cloud_id)
    cfg.elasticsearch_api_key = os.environ.get("LOG_ES_API_KEY", cfg.elasticsearch_api_key)
    cfg.elasticsearch_basic_auth_user = os.environ.get("LOG_ES_AUTH_USER", cfg.elasticsearch_basic_auth_user)
    cfg.elasticsearch_basic_auth_password = os.environ.get("LOG_ES_AUTH_PASS", cfg.elasticsearch_basic_auth_password)
    cfg.elasticsearch_batch_size = _env_int("LOG_ES_BATCH_SIZE", cfg.elasticsearch_batch_size)
    cfg.elasticsearch_flush_interval = _env_float("LOG_ES_FLUSH_INTERVAL", cfg.elasticsearch_flush_interval)
    cfg.elasticsearch_level = os.environ.get("LOG_ES_LEVEL", cfg.elasticsearch_level).upper()

    # Sentry integration
    cfg.sentry_enabled = _env_bool("LOG_SENTRY", cfg.sentry_enabled)
    cfg.sentry_dsn = os.environ.get("LOG_SENTRY_DSN", cfg.sentry_dsn)
    cfg.sentry_environment = os.environ.get("LOG_SENTRY_ENV", cfg.sentry_environment)
    cfg.sentry_release = os.environ.get("LOG_SENTRY_RELEASE", cfg.sentry_release)
    cfg.sentry_breadcrumb_level = os.environ.get("LOG_SENTRY_BC_LEVEL", cfg.sentry_breadcrumb_level).upper()
    cfg.sentry_event_level = os.environ.get("LOG_SENTRY_EV_LEVEL", cfg.sentry_event_level).upper()
    cfg.sentry_traces_sample_rate = _env_float("LOG_SENTRY_TRACES_RATE", cfg.sentry_traces_sample_rate)

    # OpenTelemetry integration
    cfg.otel_enabled = _env_bool("LOG_OTEL", cfg.otel_enabled)
    cfg.otel_service_name = os.environ.get("LOG_OTEL_SERVICE_NAME", cfg.otel_service_name)
    cfg.otel_service_version = os.environ.get("LOG_OTEL_SERVICE_VER", cfg.otel_service_version)

    # Prometheus integration
    cfg.prometheus_enabled = _env_bool("LOG_PROMETHEUS", cfg.prometheus_enabled)
    cfg.prometheus_service_name = os.environ.get("LOG_PROM_SERVICE_NAME", cfg.prometheus_service_name)

    return cfg


# ---------------------------------------------------------------------------
# YAML / JSON file loader
# ---------------------------------------------------------------------------

def load_from_file(path: str | Path, base: Optional[LoggerConfig] = None) -> LoggerConfig:
    """Return a LoggerConfig loaded from a YAML or JSON file.

    The file may contain a flat mapping whose keys correspond to
    ``LoggerConfig`` field names.  Unknown keys are silently ignored.

    YAML support requires the ``pyyaml`` package; if it is not installed
    and a ``.yaml``/``.yml`` file is requested, ``ImportError`` is raised.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Logger config file not found: {path}")

    suffix = path.suffix.lower()
    if suffix in (".yaml", ".yml"):
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "pyyaml is required to load YAML config files. "
                "Install it with: pip install pyyaml"
            ) from exc
        with path.open() as fh:
            data: Dict[str, Any] = yaml.safe_load(fh) or {}
    elif suffix == ".json":
        with path.open() as fh:
            data = json.load(fh)
    else:
        raise ValueError(f"Unsupported config file format: {suffix!r}. Use .yaml, .yml, or .json")

    cfg = base or LoggerConfig()
    valid_fields = {f.name for f in cfg.__dataclass_fields__.values()}  # type: ignore[attr-defined]

    for key, value in data.items():
        if key in valid_fields:
            setattr(cfg, key, value)

    # Normalise level to upper-case string
    cfg.level = str(cfg.level).upper()

    return cfg


# ---------------------------------------------------------------------------
# Convenience: load everything
# ---------------------------------------------------------------------------

def build_config(
    config_file: Optional[str | Path] = None,
    **overrides: Any,
) -> LoggerConfig:
    """Build a ``LoggerConfig`` by layering defaults → env vars → file → kwargs.

    Args:
        config_file: Optional path to a YAML or JSON config file.
        **overrides:  Any ``LoggerConfig`` field can be overridden directly.

    Returns:
        A fully resolved ``LoggerConfig`` instance.
    """
    cfg = LoggerConfig()
    cfg = load_from_env(cfg)

    if config_file:
        cfg = load_from_file(config_file, cfg)

    for key, value in overrides.items():
        if hasattr(cfg, key):
            setattr(cfg, key, value)

    return cfg


def numeric_level(cfg: LoggerConfig) -> int:
    """Convert ``cfg.level`` string to a Python ``logging`` integer."""
    level = logging.getLevelName(cfg.level)
    if not isinstance(level, int):
        raise ValueError(f"Unknown log level: {cfg.level!r}")
    return level
