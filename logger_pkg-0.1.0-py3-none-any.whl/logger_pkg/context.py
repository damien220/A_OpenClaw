"""
Context propagation for logger_pkg.

Provides a thread-safe and asyncio-safe store of arbitrary key/value pairs
(e.g. correlation_id, request_id, user_id) that are automatically injected
into every log record by :class:`~logger_pkg.filters.context_filter.ContextFilter`.

Usage::

    from logger_pkg.context import bind_context, reset_context, get_context

    # At the start of a request / task:
    token = bind_context(correlation_id="abc-123", user_id=42)

    # … log statements here will carry those fields automatically …

    # At the end of the request / task:
    reset_context(token)

Alternatively, use the context manager::

    with bound_context(correlation_id="abc-123"):
        logger.info("Handled request")
"""

from __future__ import annotations

import uuid
from contextlib import contextmanager
from contextvars import ContextVar, Token
from typing import Any, Dict, Generator, Optional


# ---------------------------------------------------------------------------
# Internal storage
# ---------------------------------------------------------------------------

# Single ContextVar that holds the entire context mapping.
# Using one var instead of one-per-key keeps the reset API simple.
_context_store: ContextVar[Dict[str, Any]] = ContextVar(
    "logger_pkg_context", default={}
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def bind_context(**fields: Any) -> Token[Dict[str, Any]]:
    """Merge *fields* into the current logging context.

    Returns the :class:`~contextvars.Token` produced by the underlying
    ``ContextVar.set()`` call so the caller can restore the previous state
    with :func:`reset_context`.

    This function is safe to call from both synchronous code (threads) and
    asynchronous code (asyncio tasks), because ``ContextVar`` is isolated
    per-task and per-thread.

    Args:
        **fields: Arbitrary key/value pairs to attach to log records.

    Returns:
        A ``Token`` that can be passed to :func:`reset_context`.
    """
    new_ctx = {**_context_store.get(), **fields}
    return _context_store.set(new_ctx)


def reset_context(token: Optional[Token[Dict[str, Any]]] = None) -> None:
    """Restore the context to the state captured by *token*.

    If *token* is ``None`` the context is cleared entirely.

    Args:
        token: The value returned by a previous :func:`bind_context` call,
               or ``None`` to clear all context.
    """
    if token is None:
        _context_store.set({})
    else:
        _context_store.reset(token)


def get_context() -> Dict[str, Any]:
    """Return a shallow copy of the current logging context mapping."""
    return dict(_context_store.get())


def clear_context() -> None:
    """Remove all fields from the current logging context."""
    _context_store.set({})


@contextmanager
def bound_context(**fields: Any) -> Generator[None, None, None]:
    """Context manager that binds *fields* for the duration of the block.

    The previous context is restored when the block exits, even on exception.

    Example::

        with bound_context(request_id="xyz"):
            logger.info("Processing request")
    """
    token = bind_context(**fields)
    try:
        yield
    finally:
        reset_context(token)


def new_correlation_id() -> str:
    """Generate a new random UUID4 string suitable for use as a correlation ID."""
    return str(uuid.uuid4())
