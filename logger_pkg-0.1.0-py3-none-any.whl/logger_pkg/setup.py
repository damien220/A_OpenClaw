"""
setup_logging() — the main entry-point for configuring the logging pipeline.

This factory reads a :class:`~logger_pkg.config.LoggerConfig` (or builds one
transparently), constructs formatters, filters, and handlers, optionally
wraps everything in an async queue, and attaches the result to the named
logger (or root logger).

Typical usage — zero-config (console, INFO, human-readable)::

    from logger_pkg import setup_logging
    setup_logging()

Production usage — JSON, file + console, async queue, PII filter::

    from logger_pkg import setup_logging
    from logger_pkg.config import build_config

    cfg = build_config(
        config_file="logger.yaml",   # or set LOG_* env vars
        level="INFO",
        format="json",
        file_enabled=True,
        file_path="/var/log/myapp/app.log",
        pii_filter_enabled=True,
        async_queue_enabled=True,
    )
    listener = setup_logging(config=cfg, logger_name="myapp")

    # On shutdown:
    if listener:
        listener.stop()
"""

from __future__ import annotations

import logging
import logging.handlers
import sys
from typing import List, Optional, Tuple

from .config import LoggerConfig, build_config, numeric_level
from .filters.context_filter import ContextFilter
from .filters.pii_filter import PIIFilter
from .filters.sampling_filter import SamplingFilter
from .formatters.console_formatter import ConsoleFormatter
from .formatters.json_formatter import JSONFormatter
from .handlers.async_queue import build_queue_pair
from .handlers.rotating_file import (
    build_rotating_file_handler,
    build_timed_rotating_file_handler,
)


def setup_logging(
    config: Optional[LoggerConfig] = None,
    logger_name: Optional[str] = None,
    config_file: Optional[str] = None,
    **config_overrides,
) -> Optional[logging.handlers.QueueListener]:
    """Configure the logging pipeline and return the QueueListener (if used).

    Args:
        config: A pre-built :class:`~logger_pkg.config.LoggerConfig`.  If
                omitted, one is constructed from environment variables and
                *config_file* / *config_overrides*.
        logger_name: Name of the logger to configure.  ``None`` targets the
                     root logger.
        config_file: Path to a YAML or JSON config file.
        **config_overrides: Any :class:`~logger_pkg.config.LoggerConfig`
                            field can be overridden here directly.

    Returns:
        The :class:`~logging.handlers.QueueListener` instance if
        ``async_queue_enabled`` is ``True``, otherwise ``None``.
        **Remember to call** ``listener.stop()`` during application shutdown
        to flush in-flight records and join the background thread.
    """
    if config is None:
        config = build_config(config_file=config_file, **config_overrides)

    logger = logging.getLogger(logger_name)
    logger.setLevel(numeric_level(config))
    logger.propagate = config.propagate

    # Remove any previously attached handlers so setup_logging() is
    # idempotent (safe to call multiple times, e.g. in tests).
    logger.handlers.clear()

    # ------------------------------------------------------------------
    # Build formatter
    # ------------------------------------------------------------------
    formatter = _build_formatter(config)

    # ------------------------------------------------------------------
    # Build "real" I/O handlers
    # ------------------------------------------------------------------
    io_handlers: List[logging.Handler] = []

    if config.console_enabled:
        io_handlers.append(_build_console_handler(config, formatter))

    if config.file_enabled:
        io_handlers.append(_build_file_handler(config, formatter))

    # Database handler (Phase 2 — via db_accessor)
    db_handler = None
    if config.db_enabled:
        db_handler = _build_db_handler(config, formatter)

    if not io_handlers:
        # Safety: always emit somewhere so logs are not silently lost.
        io_handlers.append(_build_console_handler(config, formatter))

    # ------------------------------------------------------------------
    # Attach filters to every I/O handler
    # ------------------------------------------------------------------
    for handler in io_handlers:
        _attach_filters(handler, config)

    # ------------------------------------------------------------------
    # Async queue (wraps all I/O handlers)
    # ------------------------------------------------------------------
    listener: Optional[logging.handlers.QueueListener] = None

    if config.async_queue_enabled:
        queue_handler, listener = build_queue_pair(
            handlers=io_handlers,
            queue_size=config.async_queue_size,
            auto_start=True,
        )
        logger.addHandler(queue_handler)
    else:
        for handler in io_handlers:
            logger.addHandler(handler)

    # Database handler has its own internal queue, so attach it directly
    # to the logger (not through the async queue).
    if db_handler is not None:
        _attach_filters(db_handler, config)
        logger.addHandler(db_handler)

    # ------------------------------------------------------------------
    # External service handlers (Phase 3)
    # Each has its own buffering / batching, so attach directly.
    # ------------------------------------------------------------------
    for ext_handler in _build_external_handlers(config, formatter):
        _attach_filters(ext_handler, config)
        logger.addHandler(ext_handler)

    # ------------------------------------------------------------------
    # Sentry (not a handler — hooks into logging via SDK)
    # ------------------------------------------------------------------
    if config.sentry_enabled and config.sentry_dsn:
        _configure_sentry(config)

    # ------------------------------------------------------------------
    # Monitoring integrations (Phase 4)
    # ------------------------------------------------------------------
    if config.otel_enabled:
        _enable_otel(config)

    if config.prometheus_enabled:
        prom_handler = _build_prometheus_handler(config)
        if prom_handler is not None:
            logger.addHandler(prom_handler)

    return listener


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _build_formatter(config: LoggerConfig) -> logging.Formatter:
    if config.format == "json":
        return JSONFormatter(extra_fields=config.extra_fields or None)
    return ConsoleFormatter()


def _build_console_handler(
    config: LoggerConfig, formatter: logging.Formatter
) -> logging.Handler:
    stream = sys.stdout if config.console_stream == "stdout" else sys.stderr
    handler = logging.StreamHandler(stream)
    handler.setLevel(numeric_level(config))
    handler.setFormatter(formatter)
    return handler


def _build_file_handler(
    config: LoggerConfig, formatter: logging.Formatter
) -> logging.Handler:
    level = numeric_level(config)
    if config.file_rotation == "size":
        return build_rotating_file_handler(
            path=config.file_path,
            max_bytes=config.file_max_bytes,
            backup_count=config.file_backup_count,
            gzip_rotated=config.file_gzip,
            level=level,
            formatter=formatter,
        )
    elif config.file_rotation == "time":
        return build_timed_rotating_file_handler(
            path=config.file_path,
            when=config.file_when,
            interval=config.file_interval,
            backup_count=config.file_backup_count,
            gzip_rotated=config.file_gzip,
            level=level,
            formatter=formatter,
        )
    else:
        # "none" — plain FileHandler, no rotation
        handler = logging.FileHandler(config.file_path, encoding="utf-8", delay=True)
        handler.setLevel(level)
        handler.setFormatter(formatter)
        return handler


def _build_db_handler(
    config: LoggerConfig, formatter: logging.Formatter
) -> logging.Handler:
    from .handlers.database import build_database_handler

    db_level = logging.getLevelName(config.db_level)
    if not isinstance(db_level, int):
        db_level = logging.WARNING

    conn_details = config.db_connection_details
    # Default SQLite connection if no details provided
    if not conn_details and config.db_type == "sqlite":
        conn_details = {"file": "logs.db"}

    return build_database_handler(
        db_type=config.db_type,
        connection_details=conn_details,
        table=config.db_table,
        queue_size=config.db_queue_size,
        batch_size=config.db_batch_size,
        flush_interval=config.db_flush_interval,
        retry_attempts=config.db_retry_attempts,
        level=db_level,
        formatter=formatter,
    )


def _build_external_handlers(
    config: LoggerConfig, formatter: logging.Formatter
) -> List[logging.Handler]:
    """Build external service handlers enabled in *config*."""
    handlers: List[logging.Handler] = []

    if config.cloudwatch_enabled:
        from .handlers.external.cloudwatch_handler import CloudWatchHandler

        cw_level = logging.getLevelName(config.cloudwatch_level)
        if not isinstance(cw_level, int):
            cw_level = logging.INFO

        handler = CloudWatchHandler(
            log_group=config.cloudwatch_log_group,
            stream_name=config.cloudwatch_stream_name,
            region_name=config.cloudwatch_region,
            send_interval=config.cloudwatch_send_interval,
            retention_days=config.cloudwatch_retention_days,
            level=cw_level,
            formatter=formatter,
        )
        handlers.append(handler)

    if config.loki_enabled and config.loki_url:
        from .handlers.external.loki_handler import LokiHandler

        loki_level = logging.getLevelName(config.loki_level)
        if not isinstance(loki_level, int):
            loki_level = logging.INFO

        auth = None
        if config.loki_auth_user and config.loki_auth_password:
            auth = (config.loki_auth_user, config.loki_auth_password)

        handler = LokiHandler(
            url=config.loki_url,
            labels=config.loki_labels or None,
            auth=auth,
            level=loki_level,
            formatter=formatter,
        )
        handlers.append(handler)

    if config.elasticsearch_enabled and config.elasticsearch_hosts:
        from .handlers.external.elasticsearch_handler import ElasticsearchHandler

        es_level = logging.getLevelName(config.elasticsearch_level)
        if not isinstance(es_level, int):
            es_level = logging.INFO

        es_kwargs: dict = {
            "hosts": config.elasticsearch_hosts,
            "index_prefix": config.elasticsearch_index_prefix,
            "batch_size": config.elasticsearch_batch_size,
            "flush_interval": config.elasticsearch_flush_interval,
            "level": es_level,
            "formatter": formatter,
        }
        if config.elasticsearch_cloud_id:
            es_kwargs["cloud_id"] = config.elasticsearch_cloud_id
        if config.elasticsearch_api_key:
            es_kwargs["api_key"] = config.elasticsearch_api_key
        if config.elasticsearch_basic_auth_user and config.elasticsearch_basic_auth_password:
            es_kwargs["basic_auth"] = (
                config.elasticsearch_basic_auth_user,
                config.elasticsearch_basic_auth_password,
            )

        handler = ElasticsearchHandler(**es_kwargs)
        handlers.append(handler)

    return handlers


def _configure_sentry(config: LoggerConfig) -> None:
    """Initialise Sentry SDK from config."""
    from .handlers.external.sentry_handler import configure_sentry

    bc_level = logging.getLevelName(config.sentry_breadcrumb_level)
    ev_level = logging.getLevelName(config.sentry_event_level)

    configure_sentry(
        dsn=config.sentry_dsn,
        environment=config.sentry_environment,
        release=config.sentry_release or None,
        breadcrumb_level=bc_level if isinstance(bc_level, int) else logging.INFO,
        event_level=ev_level if isinstance(ev_level, int) else logging.ERROR,
        traces_sample_rate=config.sentry_traces_sample_rate,
    )


def _enable_otel(config: LoggerConfig) -> None:
    """Activate OpenTelemetry log instrumentation."""
    from .integrations.opentelemetry import enable_otel

    enable_otel(
        service_name=config.otel_service_name,
        service_version=config.otel_service_version,
    )


def _build_prometheus_handler(config: LoggerConfig) -> Optional[logging.Handler]:
    """Create a Prometheus metrics handler."""
    from .integrations.prometheus import get_metrics_handler

    return get_metrics_handler(service_name=config.prometheus_service_name)


def _attach_filters(handler: logging.Handler, config: LoggerConfig) -> None:
    # Context injection — always on
    handler.addFilter(ContextFilter())

    if config.pii_filter_enabled:
        handler.addFilter(PIIFilter(extra_patterns=[
            (p, "[REDACTED]") for p in config.pii_patterns
        ]))

    if config.sampling_filter_enabled:
        level_int = logging.getLevelName(config.sampling_level)
        handler.addFilter(SamplingFilter(
            rate=config.sampling_rate,
            max_level=level_int if isinstance(level_int, int) else logging.DEBUG,
        ))


def get_logger(name: str) -> logging.Logger:
    """Convenience wrapper around :func:`logging.getLogger`.

    Importing from ``logger_pkg`` rather than ``logging`` directly makes
    future centralized customisation easier (e.g. lazy-string support).

    Args:
        name: Logger name, typically ``__name__`` of the calling module.

    Returns:
        A standard :class:`logging.Logger` instance.
    """
    return logging.getLogger(name)
