"""
logger_pkg — a unified, reusable logging package.

Quick start (zero-config)::

    from logger_pkg import setup_logging, get_logger

    setup_logging()                          # console, INFO, human-readable
    log = get_logger(__name__)
    log.info("Application started")

Production start (JSON + file + async queue)::

    from logger_pkg import setup_logging, get_logger, bind_context
    from logger_pkg.config import build_config

    cfg = build_config(
        format="json",
        file_enabled=True,
        file_path="logs/app.log",
        async_queue_enabled=True,
        pii_filter_enabled=True,
    )
    listener = setup_logging(config=cfg)

    log = get_logger("myapp")

    bind_context(service="myapp", version="1.0.0")
    log.info("Server ready")

    # On shutdown:
    if listener:
        listener.stop()

Public API (Phase 1)
--------------------
setup_logging   Configure the whole logging pipeline.
get_logger      Get (or create) a named logger.
bind_context    Attach context fields to the current thread / asyncio task.
reset_context   Remove context fields (restores previous state via Token).
bound_context   Context manager version of bind_context / reset_context.
get_context     Inspect the current context dict.
clear_context   Remove all context fields.
new_correlation_id  Generate a random UUID4 string.
LoggerConfig    Configuration dataclass.
build_config    Build a LoggerConfig from env vars + file + kwargs.
"""

from .config import LoggerConfig, build_config
from .context import (
    bind_context,
    bound_context,
    clear_context,
    get_context,
    new_correlation_id,
    reset_context,
)
from .setup import get_logger, setup_logging

__all__ = [
    # Core setup
    "setup_logging",
    "get_logger",
    # Config
    "LoggerConfig",
    "build_config",
    # Context
    "bind_context",
    "reset_context",
    "bound_context",
    "get_context",
    "clear_context",
    "new_correlation_id",
]

__version__ = "0.1.0"
