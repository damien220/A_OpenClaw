"""
JSONFormatter — emits a single-line JSON object per log record.

Every record contains the following base fields:

    timestamp   ISO-8601 UTC timestamp with millisecond precision
    level       Level name (DEBUG, INFO, …)
    logger      Logger name
    message     Formatted log message
    module      Source module name
    func        Calling function name
    line        Source line number

Additional fields are merged in from:
  * The ``extra`` dict passed to the logging call.
  * The ContextVar store (injected upstream by ContextFilter).
  * ``exc_info`` — serialised exception traceback if present.
  * ``stack_info`` — stack info string if present.
  * ``extra_fields`` provided at formatter construction time.
"""

from __future__ import annotations

import datetime
import json
import logging
import traceback
from typing import Any, Dict, Optional


class JSONFormatter(logging.Formatter):
    """Format log records as single-line JSON.

    Args:
        extra_fields: Static key/value pairs merged into **every** record.
        indent: If set, pretty-print JSON with this indentation (debug only).
        ensure_ascii: Passed directly to ``json.dumps``.
        timestamp_key: Key name for the timestamp field (default ``"timestamp"``).
    """

    # Fields that live on LogRecord but should NOT be copied verbatim into
    # the JSON output (they are either remapped or internal).
    _SKIP = frozenset({
        "args", "created", "exc_info", "exc_text", "filename",
        "funcName", "levelname", "levelno", "lineno", "message",
        "module", "msecs", "msg", "name", "pathname", "process",
        "processName", "relativeCreated", "stack_info", "taskName",
        "thread", "threadName",
    })

    def __init__(
        self,
        extra_fields: Optional[Dict[str, Any]] = None,
        indent: Optional[int] = None,
        ensure_ascii: bool = False,
        timestamp_key: str = "timestamp",
    ) -> None:
        super().__init__()
        self._extra_fields: Dict[str, Any] = extra_fields or {}
        self._indent = indent
        self._ensure_ascii = ensure_ascii
        self._timestamp_key = timestamp_key

    # ------------------------------------------------------------------
    # Core
    # ------------------------------------------------------------------

    def format(self, record: logging.LogRecord) -> str:
        record.message = record.getMessage()

        payload: Dict[str, Any] = {
            self._timestamp_key: self._utc_timestamp(record),
            "level": record.levelname,
            "logger": record.name,
            "message": record.message,
            "module": record.module,
            "func": record.funcName,
            "line": record.lineno,
        }

        # Static extra fields from formatter config
        if self._extra_fields:
            payload.update(self._extra_fields)

        # Dynamic extra fields attached to the record
        # (includes anything injected by ContextFilter)
        for key, value in record.__dict__.items():
            if key not in self._SKIP and not key.startswith("_"):
                payload[key] = value

        # Exception info
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)

        if record.stack_info:
            payload["stack_info"] = self.formatStack(record.stack_info)

        return json.dumps(payload, default=self._default_serialiser,
                          indent=self._indent, ensure_ascii=self._ensure_ascii)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _utc_timestamp(record: logging.LogRecord) -> str:
        dt = datetime.datetime.fromtimestamp(record.created, tz=datetime.timezone.utc)
        return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"

    @staticmethod
    def _default_serialiser(obj: Any) -> Any:
        """Fallback serialiser for non-JSON-native types."""
        if isinstance(obj, (set, frozenset)):
            return list(obj)
        if isinstance(obj, bytes):
            return obj.decode("utf-8", errors="replace")
        if hasattr(obj, "__str__"):
            return str(obj)
        raise TypeError(f"Object of type {type(obj).__name__} is not JSON serialisable")
