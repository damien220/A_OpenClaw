"""
ConsoleFormatter — human-readable, optionally colourised log output.

Colour is applied automatically when the target stream is a real TTY.
It can be forced on or off via the *force_color* constructor argument.

Colour codes map to ANSI escape sequences and are skipped on Windows
if ``colorama`` is not installed (falls back gracefully to no colour).

Level colours (customisable via *level_colors*):

    DEBUG    — cyan
    INFO     — green
    WARNING  — yellow
    ERROR    — red
    CRITICAL — bold red
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Dict, Optional


# ---------------------------------------------------------------------------
# ANSI colour constants
# ---------------------------------------------------------------------------

RESET = "\033[0m"
BOLD = "\033[1m"

_ANSI = {
    "black":   "\033[30m",
    "red":     "\033[31m",
    "green":   "\033[32m",
    "yellow":  "\033[33m",
    "blue":    "\033[34m",
    "magenta": "\033[35m",
    "cyan":    "\033[36m",
    "white":   "\033[37m",
    "bold_red": "\033[1;31m",
}

_DEFAULT_LEVEL_COLORS: Dict[int, str] = {
    logging.DEBUG:    _ANSI["cyan"],
    logging.INFO:     _ANSI["green"],
    logging.WARNING:  _ANSI["yellow"],
    logging.ERROR:    _ANSI["red"],
    logging.CRITICAL: _ANSI["bold_red"],
}

# Default format string (used when no fmt is supplied)
_DEFAULT_FMT = "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s"
_DEFAULT_DATE_FMT = "%Y-%m-%d %H:%M:%S"


# ---------------------------------------------------------------------------
# Formatter
# ---------------------------------------------------------------------------

class ConsoleFormatter(logging.Formatter):
    """Human-readable log formatter with optional ANSI colour support.

    Args:
        fmt: ``logging``-style format string.  Defaults to a timestamp +
             level + logger name + line number + message layout.
        datefmt: Date format string passed to ``Formatter``.
        force_color: ``True`` forces colour on; ``False`` forces it off;
                     ``None`` (default) auto-detects via TTY check.
        level_colors: Mapping from ``logging`` level integer to ANSI escape
                      sequence.  Merged over the built-in defaults.
    """

    def __init__(
        self,
        fmt: str = _DEFAULT_FMT,
        datefmt: str = _DEFAULT_DATE_FMT,
        force_color: Optional[bool] = None,
        level_colors: Optional[Dict[int, str]] = None,
    ) -> None:
        super().__init__(fmt=fmt, datefmt=datefmt)
        self._use_color = self._resolve_color(force_color)
        self._level_colors: Dict[int, str] = {**_DEFAULT_LEVEL_COLORS, **(level_colors or {})}

        # Try to initialise colorama on Windows so ANSI codes work in cmd.exe
        if self._use_color and sys.platform == "win32":
            try:
                import colorama  # type: ignore
                colorama.init(autoreset=False)
            except ImportError:
                self._use_color = False

    # ------------------------------------------------------------------
    # Core
    # ------------------------------------------------------------------

    def format(self, record: logging.LogRecord) -> str:
        formatted = super().format(record)
        if not self._use_color:
            return formatted

        color = self._level_colors.get(record.levelno, "")
        if color:
            return f"{color}{formatted}{RESET}"
        return formatted

    def formatException(self, ei) -> str:  # type: ignore[override]
        result = super().formatException(ei)
        if self._use_color:
            return f"{_ANSI['red']}{result}{RESET}"
        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_color(force: Optional[bool]) -> bool:
        """Determine whether colour output should be used."""
        if force is not None:
            return force

        # Respect ``NO_COLOR`` env var (https://no-color.org)
        if os.environ.get("NO_COLOR"):
            return False

        # ``FORCE_COLOR`` env var
        if os.environ.get("FORCE_COLOR"):
            return True

        # Check if stderr (typical console target) is a TTY
        return hasattr(sys.stderr, "isatty") and sys.stderr.isatty()
