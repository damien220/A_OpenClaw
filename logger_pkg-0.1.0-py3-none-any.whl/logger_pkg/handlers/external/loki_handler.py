"""
LokiHandler — push log records to Grafana Loki via HTTP.

Zero external dependencies — uses stdlib ``urllib.request``.  If
``python-logging-loki`` is installed it will be preferred for richer
features (batching, retries, label sniffing).

Usage (stdlib, zero-dep)::

    from logger_pkg.handlers.external.loki_handler import LokiHandler

    handler = LokiHandler(
        url="http://loki:3100/loki/api/v1/push",
        labels={"app": "myapp", "env": "production"},
    )

Usage (Grafana Cloud with basic auth)::

    handler = LokiHandler(
        url="https://logs-prod-us-central1.grafana.net/loki/api/v1/push",
        labels={"app": "myapp"},
        auth=("user_id", "api_key"),
    )
"""

from __future__ import annotations

import base64
import json
import logging
import time
import urllib.error
import urllib.request
from typing import Dict, Optional, Tuple


class LokiHandler(logging.Handler):
    """Logging handler that pushes records to Grafana Loki.

    Uses the ``/loki/api/v1/push`` endpoint. Each log record is sent
    as a single stream entry with the configured labels.

    If ``python-logging-loki`` is installed, this handler delegates to
    it for built-in batching and retry support. Otherwise, a lightweight
    stdlib implementation is used.

    Args:
        url: Loki push API URL (e.g. ``"http://loki:3100/loki/api/v1/push"``).
        labels: Dict of static labels attached to every stream entry.
        auth: Optional ``(username, password)`` tuple for HTTP Basic Auth
              (required for Grafana Cloud).
        level: Minimum log level to ship.
        formatter: Optional formatter. If ``None``, the raw message is sent.
        timeout: HTTP request timeout in seconds.
        use_library: If ``True`` (default) and ``python-logging-loki`` is
                     installed, delegate to it. Set ``False`` to force the
                     stdlib implementation.
    """

    def __init__(
        self,
        url: str,
        labels: Optional[Dict[str, str]] = None,
        auth: Optional[Tuple[str, str]] = None,
        level: int = logging.NOTSET,
        formatter: Optional[logging.Formatter] = None,
        timeout: int = 10,
        use_library: bool = True,
    ) -> None:
        super().__init__(level)

        self._url = url
        self._labels = labels or {"source": "logger_pkg"}
        self._auth = auth
        self._timeout = timeout
        self._delegate: Optional[logging.Handler] = None

        if formatter:
            self.setFormatter(formatter)

        # Try to use python-logging-loki if available
        if use_library:
            try:
                import logging_loki  # type: ignore

                loki_kwargs: dict = {
                    "url": url,
                    "tags": self._labels,
                    "version": "1",
                }
                if auth:
                    loki_kwargs["auth"] = auth

                self._delegate = logging_loki.LokiHandler(**loki_kwargs)
                if formatter:
                    self._delegate.setFormatter(formatter)
            except ImportError:
                pass  # Fall through to stdlib implementation

    def emit(self, record: logging.LogRecord) -> None:
        if self._delegate is not None:
            self._delegate.emit(record)
            return

        try:
            self._push_stdlib(record)
        except Exception:
            self.handleError(record)

    def _push_stdlib(self, record: logging.LogRecord) -> None:
        """Push a single record via stdlib ``urllib``."""
        message = self.format(record) if self.formatter else record.getMessage()

        # Loki expects nanosecond timestamps as strings
        ts_ns = str(int(record.created * 1_000_000_000))

        # Build dynamic labels from record
        labels = dict(self._labels)
        labels["level"] = record.levelname.lower()
        labels["logger"] = record.name

        payload = {
            "streams": [
                {
                    "stream": labels,
                    "values": [[ts_ns, message]],
                }
            ]
        }

        data = json.dumps(payload).encode("utf-8")

        req = urllib.request.Request(
            self._url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        if self._auth:
            credentials = base64.b64encode(
                f"{self._auth[0]}:{self._auth[1]}".encode()
            ).decode("ascii")
            req.add_header("Authorization", f"Basic {credentials}")

        try:
            urllib.request.urlopen(req, timeout=self._timeout)
        except urllib.error.HTTPError as e:
            if e.code >= 500:
                # Server error — transient, don't crash
                import sys
                print(
                    f"[logger_pkg] WARNING: Loki push failed ({e.code}): {e.reason}",
                    file=sys.stderr,
                )
            else:
                raise

    def close(self) -> None:
        if self._delegate is not None:
            self._delegate.close()
        super().close()
