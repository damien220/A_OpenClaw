"""
Sentry integration — error tracking for logger_pkg.

Configures ``sentry-sdk`` with ``LoggingIntegration`` so that:

* INFO+ log records are captured as **breadcrumbs** (context trail).
* ERROR+ log records are captured as **Sentry events** (alerts).

Requires::

    pip install sentry-sdk>=2.0
    # or: pip install logger_pkg[sentry]

Usage::

    from logger_pkg.handlers.external.sentry_handler import configure_sentry

    configure_sentry(
        dsn="https://examplePublicKey@o0.ingest.sentry.io/0",
        environment="production",
        release="myapp@1.2.3",
    )

This is **not** a ``logging.Handler`` subclass — Sentry's SDK hooks into
the logging system automatically via ``LoggingIntegration``.  The
:func:`configure_sentry` helper simply calls ``sentry_sdk.init()`` with
safe defaults.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional


def _require_sentry():
    try:
        import sentry_sdk  # type: ignore
        return sentry_sdk
    except ImportError as exc:
        raise ImportError(
            "sentry-sdk is required for Sentry integration. "
            "Install it with: pip install sentry-sdk>=2.0"
        ) from exc


def _default_before_send(
    event: Dict[str, Any], hint: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """Default ``before_send`` hook that scrubs sensitive headers.

    Removes ``Authorization``, ``Cookie``, and ``X-Api-Key`` from
    request headers if present.
    """
    request = event.get("request", {})
    headers = request.get("headers", {})
    if headers:
        sensitive = {"Authorization", "Cookie", "X-Api-Key", "X-Auth-Token"}
        for key in list(headers.keys()):
            if key in sensitive or key.lower() in {s.lower() for s in sensitive}:
                headers[key] = "[REDACTED]"
    return event


def configure_sentry(
    dsn: str,
    environment: str = "production",
    release: Optional[str] = None,
    breadcrumb_level: int = logging.INFO,
    event_level: int = logging.ERROR,
    before_send: Optional[Callable] = None,
    traces_sample_rate: float = 0.0,
    **extra_kwargs: Any,
) -> None:
    """Initialise Sentry SDK with safe defaults for logger_pkg.

    Args:
        dsn: Sentry Data Source Name (project-specific URL).
        environment: Deployment environment tag (``"production"``,
                     ``"staging"``, ``"development"``).
        release: Application release/version string (e.g. ``"myapp@1.2.3"``).
        breadcrumb_level: Minimum level captured as breadcrumbs (context
                          trail). Default: ``logging.INFO``.
        event_level: Minimum level captured as Sentry events (alerts).
                     Default: ``logging.ERROR``.
        before_send: Optional ``before_send`` callback. If ``None``, a
                     default hook that scrubs Authorization/Cookie headers
                     is used.
        traces_sample_rate: Fraction of transactions to send for
                            performance monitoring (``0.0`` = disabled).
        **extra_kwargs: Passed directly to ``sentry_sdk.init()``.
    """
    sentry_sdk = _require_sentry()
    from sentry_sdk.integrations.logging import LoggingIntegration  # type: ignore

    logging_integration = LoggingIntegration(
        level=breadcrumb_level,
        event_level=event_level,
    )

    init_kwargs: Dict[str, Any] = {
        "dsn": dsn,
        "environment": environment,
        "integrations": [logging_integration],
        "send_default_pii": False,  # Always enforce — never send PII
        "traces_sample_rate": traces_sample_rate,
        "before_send": before_send or _default_before_send,
    }

    if release:
        init_kwargs["release"] = release

    init_kwargs.update(extra_kwargs)

    sentry_sdk.init(**init_kwargs)
