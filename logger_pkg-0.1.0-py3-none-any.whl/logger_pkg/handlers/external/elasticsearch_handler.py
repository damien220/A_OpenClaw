"""
ElasticsearchHandler — batch-index log records to Elasticsearch.

Requires::

    pip install elasticsearch>=8.0
    # or: pip install logger_pkg[elasticsearch]

Records are buffered in memory and flushed in batches using
``elasticsearch.helpers.bulk()``.  A background thread handles the
actual I/O.

Usage::

    from logger_pkg.handlers.external.elasticsearch_handler import ElasticsearchHandler

    handler = ElasticsearchHandler(
        hosts=["http://localhost:9200"],
        index_prefix="myapp-logs",
    )
"""

from __future__ import annotations

import json
import logging
import queue
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _require_elasticsearch():
    try:
        import elasticsearch  # type: ignore
        return elasticsearch
    except ImportError as exc:
        raise ImportError(
            "elasticsearch is required for Elasticsearch logging. "
            "Install it with: pip install elasticsearch>=8.0"
        ) from exc


# Standard LogRecord attributes to exclude from extra fields
_BUILTIN_ATTRS = frozenset({
    "args", "created", "exc_info", "exc_text", "filename", "funcName",
    "levelname", "levelno", "lineno", "message", "module", "msecs", "msg",
    "name", "pathname", "process", "processName", "relativeCreated",
    "stack_info", "thread", "threadName", "taskName",
})


def _record_to_doc(record: logging.LogRecord) -> Dict[str, Any]:
    """Convert a LogRecord to an Elasticsearch document."""
    doc: Dict[str, Any] = {
        "@timestamp": datetime.fromtimestamp(
            record.created, tz=timezone.utc
        ).isoformat(),
        "level": record.levelname,
        "logger": record.name,
        "message": record.getMessage(),
        "module": record.module,
        "function": record.funcName,
        "line": record.lineno,
        "process": record.process,
        "thread": record.thread,
    }

    # Exception info
    if record.exc_info and record.exc_info[1] is not None:
        import traceback
        doc["exception"] = "".join(traceback.format_exception(*record.exc_info))
    elif record.exc_text:
        doc["exception"] = record.exc_text

    # Extra fields (flatten into document)
    for key, value in record.__dict__.items():
        if key.startswith("_") or key in _BUILTIN_ATTRS:
            continue
        try:
            json.dumps(value)
            doc[key] = value
        except (TypeError, ValueError):
            doc[key] = str(value)

    return doc


class ElasticsearchHandler(logging.Handler):
    """Buffered handler that batch-indexes log records to Elasticsearch.

    Args:
        hosts: List of Elasticsearch host URLs.
        index_prefix: Prefix for daily rolling indices.  The final index
                      name is ``{prefix}-{YYYY.MM.DD}``.
        api_key: Optional API key ``(id, api_key)`` tuple for authentication.
        basic_auth: Optional ``(username, password)`` tuple.
        cloud_id: Optional Elastic Cloud deployment ID.
        batch_size: Max documents per bulk request.
        flush_interval: Max seconds between flush cycles.
        queue_size: In-memory buffer capacity.
        level: Minimum log level to index.
        formatter: Optional formatter (used for ``message`` field if set).
        es_kwargs: Extra keyword arguments passed to ``Elasticsearch()``.
    """

    def __init__(
        self,
        hosts: Optional[List[str]] = None,
        index_prefix: str = "app-logs",
        api_key: Optional[tuple] = None,
        basic_auth: Optional[tuple] = None,
        cloud_id: Optional[str] = None,
        batch_size: int = 100,
        flush_interval: float = 5.0,
        queue_size: int = 10_000,
        level: int = logging.NOTSET,
        formatter: Optional[logging.Formatter] = None,
        **es_kwargs: Any,
    ) -> None:
        super().__init__(level)

        es_module = _require_elasticsearch()

        # Build client
        client_kwargs: Dict[str, Any] = {}
        if hosts:
            client_kwargs["hosts"] = hosts
        if api_key:
            client_kwargs["api_key"] = api_key
        if basic_auth:
            client_kwargs["basic_auth"] = basic_auth
        if cloud_id:
            client_kwargs["cloud_id"] = cloud_id
        client_kwargs.update(es_kwargs)

        self._client = es_module.Elasticsearch(**client_kwargs)
        self._helpers = es_module.helpers
        self._index_prefix = index_prefix
        self._batch_size = batch_size
        self._flush_interval = flush_interval

        if formatter:
            self.setFormatter(formatter)

        self._queue: queue.Queue[Optional[logging.LogRecord]] = queue.Queue(
            maxsize=queue_size,
        )
        self._stop_event = threading.Event()

        self._thread = threading.Thread(
            target=self._drain_loop,
            name="logger_pkg.es_writer",
            daemon=True,
        )
        self._thread.start()

    def _index_name(self) -> str:
        """Return today's index name."""
        return (
            f"{self._index_prefix}-"
            f"{datetime.now(timezone.utc).strftime('%Y.%m.%d')}"
        )

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self._queue.put_nowait(record)
        except queue.Full:
            self.handleError(record)

    def close(self) -> None:
        if self._stop_event.is_set():
            return
        self._stop_event.set()
        try:
            self._queue.put_nowait(None)
        except queue.Full:
            pass
        self._thread.join(timeout=10)
        self._client.close()
        super().close()

    # ------------------------------------------------------------------
    # Background writer
    # ------------------------------------------------------------------

    def _drain_loop(self) -> None:
        batch: List[Dict[str, Any]] = []
        last_flush = time.monotonic()

        while not self._stop_event.is_set() or not self._queue.empty():
            try:
                record = self._queue.get(timeout=self._flush_interval)
            except queue.Empty:
                if batch:
                    self._flush(batch)
                    batch = []
                    last_flush = time.monotonic()
                continue

            if record is None:
                break

            doc = _record_to_doc(record)
            doc["_index"] = self._index_name()
            batch.append(doc)

            elapsed = time.monotonic() - last_flush
            if len(batch) >= self._batch_size or elapsed >= self._flush_interval:
                self._flush(batch)
                batch = []
                last_flush = time.monotonic()

        if batch:
            self._flush(batch)

    def _flush(self, batch: List[Dict[str, Any]]) -> None:
        """Bulk-index a batch of documents."""
        try:
            self._helpers.bulk(self._client, batch, raise_on_error=False)
        except Exception:
            import sys
            print(
                f"[logger_pkg] ERROR: Elasticsearch bulk index failed "
                f"({len(batch)} docs)",
                file=sys.stderr,
            )
