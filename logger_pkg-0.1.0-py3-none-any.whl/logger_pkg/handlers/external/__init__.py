"""
External service log handlers.

Each handler is an optional dependency — import errors are raised at
instantiation time, not at module import time, so ``import logger_pkg``
never fails due to a missing third-party library.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .cloudwatch_handler import CloudWatchHandler
    from .elasticsearch_handler import ElasticsearchHandler
    from .loki_handler import LokiHandler
    from .sentry_handler import configure_sentry

__all__ = [
    "CloudWatchHandler",
    "LokiHandler",
    "ElasticsearchHandler",
    "configure_sentry",
]
