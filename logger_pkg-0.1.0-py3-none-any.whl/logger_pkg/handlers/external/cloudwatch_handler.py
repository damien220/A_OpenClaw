"""
CloudWatchHandler — ship Python log records to AWS CloudWatch Logs.

Thin wrapper around `watchtower.CloudWatchLogHandler` that applies
logger_pkg conventions (JSON formatting, context fields, PII scrubbing).

Requires::

    pip install watchtower boto3
    # or: pip install logger_pkg[cloudwatch]

IAM permissions needed:

    logs:CreateLogGroup
    logs:CreateLogStream
    logs:PutLogEvents
    logs:PutRetentionPolicy   (if retention_days is set)

Usage::

    from logger_pkg.handlers.external.cloudwatch_handler import CloudWatchHandler

    handler = CloudWatchHandler(
        log_group="my-app",
        stream_name="{strftime:%Y/%m/%d}",
        send_interval=5,
        region_name="us-east-1",
    )
"""

from __future__ import annotations

import logging
from typing import Optional


def _require_watchtower():
    try:
        import watchtower  # type: ignore
        return watchtower
    except ImportError as exc:
        raise ImportError(
            "watchtower is required for CloudWatch logging. "
            "Install it with: pip install watchtower boto3"
        ) from exc


class CloudWatchHandler(logging.Handler):
    """Logging handler that ships records to AWS CloudWatch Logs.

    Delegates to ``watchtower.CloudWatchLogHandler`` under the hood.

    Args:
        log_group: CloudWatch log group name.
        stream_name: Log stream name. Supports ``strftime`` tokens
                     (e.g. ``"{strftime:%Y/%m/%d}"``).
        region_name: AWS region (default ``"us-east-1"``).
        send_interval: Seconds between batch sends (default ``5``).
        retention_days: Log retention policy in days. ``None`` means
                        no retention policy is set.
        level: Minimum log level to ship.
        formatter: Optional formatter (JSON recommended for production).
        boto3_session: Optional pre-configured ``boto3.Session``.
    """

    def __init__(
        self,
        log_group: str,
        stream_name: str = "{strftime:%Y/%m/%d}",
        region_name: str = "us-east-1",
        send_interval: int = 5,
        retention_days: Optional[int] = None,
        level: int = logging.NOTSET,
        formatter: Optional[logging.Formatter] = None,
        boto3_session: Optional[object] = None,
    ) -> None:
        super().__init__(level)

        watchtower = _require_watchtower()

        kwargs: dict = {
            "log_group_name": log_group,
            "stream_name": stream_name,
            "send_interval": send_interval,
            "create_log_group": True,
        }

        if boto3_session is not None:
            kwargs["boto3_session"] = boto3_session
        else:
            import boto3  # type: ignore
            kwargs["boto3_session"] = boto3.Session(region_name=region_name)

        if retention_days is not None:
            kwargs["log_group_retention_days"] = retention_days

        self._cw_handler = watchtower.CloudWatchLogHandler(**kwargs)

        if formatter:
            self._cw_handler.setFormatter(formatter)

    def emit(self, record: logging.LogRecord) -> None:
        self._cw_handler.emit(record)

    def flush(self) -> None:
        self._cw_handler.flush()

    def close(self) -> None:
        self._cw_handler.close()
        super().close()
