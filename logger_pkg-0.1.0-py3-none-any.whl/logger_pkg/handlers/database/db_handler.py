"""
DatabaseHandler — log handler backed by ``db_accessor``.

Uses the ``db_accessor`` package to persist log records to any supported
database (SQLite, PostgreSQL, MySQL, MongoDB, Redis).  A background daemon
thread drains a bounded in-memory queue and writes records in batches,
ensuring the calling thread is never blocked by database I/O.

Usage::

    from logger_pkg.handlers.database import build_database_handler

    handler = build_database_handler(
        db_type="sqlite",
        connection_details={"file": "logs.db"},
        table="log_records",
    )
    # attach to a logger or pass to setup_logging(...)

The handler auto-creates the target table/collection on first connect
(for relational backends via ``execute_custom_query`` / ``execute_script``).

On shutdown call ``handler.close()`` to flush remaining records and join
the background thread.
"""

from __future__ import annotations

import atexit
import json
import logging
import queue
import threading
import time
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from db_accessor import get_database, list_installed_databases
from db_accessor.base import AbstractDatabase

# ---------------------------------------------------------------------------
# Schema DDL for relational backends
# ---------------------------------------------------------------------------

_SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS {table} (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp  TEXT    NOT NULL,
    level      TEXT    NOT NULL,
    level_no   INTEGER NOT NULL,
    logger     TEXT,
    message    TEXT,
    module     TEXT,
    func       TEXT,
    line       INTEGER,
    process    INTEGER,
    thread     TEXT,
    exc_text   TEXT,
    extra      TEXT
);
CREATE INDEX IF NOT EXISTS idx_{table}_timestamp ON {table} (timestamp);
CREATE INDEX IF NOT EXISTS idx_{table}_level_no  ON {table} (level_no);
"""

_PG_MYSQL_SCHEMA = """
CREATE TABLE IF NOT EXISTS {table} (
    id         SERIAL PRIMARY KEY,
    timestamp  TIMESTAMP NOT NULL,
    level      VARCHAR(10) NOT NULL,
    level_no   INTEGER NOT NULL,
    logger     VARCHAR(255),
    message    TEXT,
    module     VARCHAR(255),
    func       VARCHAR(255),
    line       INTEGER,
    process    INTEGER,
    thread     VARCHAR(255),
    exc_text   TEXT,
    extra      TEXT
);
"""

# ---------------------------------------------------------------------------
# Record serialisation
# ---------------------------------------------------------------------------

# Standard LogRecord attributes that should NOT leak into ``extra``.
_BUILTIN_ATTRS = frozenset({
    "args", "created", "exc_info", "exc_text", "filename", "funcName",
    "levelname", "levelno", "lineno", "message", "module", "msecs", "msg",
    "name", "pathname", "process", "processName", "relativeCreated",
    "stack_info", "thread", "threadName", "taskName",
})


def _record_to_dict(record: logging.LogRecord, table: str) -> Dict[str, Any]:
    """Convert a :class:`logging.LogRecord` into a flat dict for storage."""
    # Collect extra fields (anything not in the stdlib set)
    extra: Dict[str, Any] = {}
    for key, value in record.__dict__.items():
        if key.startswith("_") or key in _BUILTIN_ATTRS:
            continue
        try:
            json.dumps(value)  # only keep JSON-serialisable values
            extra[key] = value
        except (TypeError, ValueError):
            extra[key] = str(value)

    ts = datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat()

    exc_text: Optional[str] = None
    if record.exc_info and record.exc_info[1] is not None:
        exc_text = "".join(traceback.format_exception(*record.exc_info))
    elif record.exc_text:
        exc_text = record.exc_text

    return {
        "timestamp": ts,
        "level": record.levelname,
        "level_no": record.levelno,
        "logger": record.name,
        "message": record.getMessage(),
        "module": record.module,
        "func": record.funcName,
        "line": record.lineno,
        "process": record.process,
        "thread": str(record.thread),
        "exc_text": exc_text,
        "extra": json.dumps(extra) if extra else None,
    }


def _record_to_mongo_doc(record: logging.LogRecord) -> Dict[str, Any]:
    """Convert a LogRecord to a flat MongoDB document (no ``extra`` wrapper)."""
    doc = _record_to_dict(record, "")
    # Flatten extra into top-level keys for MongoDB
    extra_str = doc.pop("extra", None)
    if extra_str:
        try:
            extra_dict = json.loads(extra_str)
            doc.update(extra_dict)
        except (json.JSONDecodeError, TypeError):
            pass
    return doc


# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------

class DatabaseHandler(logging.Handler):
    """Buffered logging handler that writes to a database via ``db_accessor``.

    Records are placed on an in-memory :class:`queue.Queue` by the calling
    thread.  A daemon thread drains the queue in batches and persists them
    to the configured database.

    Args:
        db_type: One of the ``db_accessor`` backend identifiers
                 (``"sqlite"``, ``"postgres"``, ``"mysql"``, ``"mongodb"``,
                 ``"redis"``).
        connection_details: Dict passed to ``db.connect()``.
        table: Table / collection name for log records.
        queue_size: Max buffered records (0 = unbounded).
        batch_size: Records per write batch.
        flush_interval: Max seconds between flushes.
        retry_attempts: Times to retry a failed batch write.
        retry_delay: Base delay in seconds between retries (doubled each
                     attempt).
        level: Minimum log level to persist.
    """

    def __init__(
        self,
        db_type: str,
        connection_details: Dict[str, Any],
        table: str = "log_records",
        queue_size: int = 10_000,
        batch_size: int = 100,
        flush_interval: float = 2.0,
        retry_attempts: int = 3,
        retry_delay: float = 0.5,
        level: int = logging.NOTSET,
    ) -> None:
        super().__init__(level)

        self._db_type = db_type
        self._connection_details = connection_details
        self._table = table
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._retry_attempts = retry_attempts
        self._retry_delay = retry_delay
        self._is_nosql = db_type in ("mongodb", "redis")

        self._queue: queue.Queue[Optional[logging.LogRecord]] = queue.Queue(
            maxsize=queue_size,
        )
        self._stop_event = threading.Event()
        self._db: Optional[AbstractDatabase] = None
        self._connected = threading.Event()

        # Background writer thread — connection is established on this
        # thread to avoid SQLite's "same thread" restriction and to keep
        # the calling thread non-blocking during startup.
        self._thread = threading.Thread(
            target=self._drain_loop,
            name=f"logger_pkg.db_writer.{db_type}",
            daemon=True,
        )
        self._thread.start()

        # Safety net: flush on interpreter shutdown
        atexit.register(self.close)

    # ------------------------------------------------------------------
    # Connection / schema
    # ------------------------------------------------------------------

    def _connect(self) -> None:
        self._db = get_database(self._db_type)
        self._db.connect(self._connection_details)
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        """Create the log table / collection if it doesn't exist."""
        if self._db is None:
            return

        if self._db_type == "sqlite":
            schema = _SQLITE_SCHEMA.format(table=self._table)
            self._db.execute_script(schema)

        elif self._db_type in ("postgres", "mysql"):
            schema = _PG_MYSQL_SCHEMA.format(table=self._table)
            self._db.execute_custom_query(schema)

        # MongoDB and Redis don't need schema creation.

    # ------------------------------------------------------------------
    # Public logging.Handler API
    # ------------------------------------------------------------------

    def emit(self, record: logging.LogRecord) -> None:
        """Enqueue *record* for async persistence.  Never blocks."""
        try:
            self._queue.put_nowait(record)
        except queue.Full:
            self.handleError(record)

    def close(self) -> None:
        """Signal the writer thread to flush and stop, then disconnect."""
        if self._stop_event.is_set():
            return

        self._stop_event.set()
        # Send sentinel so the thread wakes up from queue.get()
        try:
            self._queue.put_nowait(None)
        except queue.Full:
            pass

        self._thread.join(timeout=10)

        if self._db is not None:
            try:
                self._db.disconnect()
            except Exception:
                pass
            self._db = None

        super().close()

    # ------------------------------------------------------------------
    # Background writer
    # ------------------------------------------------------------------

    def _drain_loop(self) -> None:
        """Background loop: drain queue, write batches, respect flush interval."""
        # Connect from this thread so the DB handle is thread-local
        # (required by SQLite, harmless for others).
        try:
            self._connect()
            self._connected.set()
        except Exception:
            import sys
            print(
                f"[logger_pkg] ERROR: failed to connect to {self._db_type} "
                f"— database logging disabled",
                file=sys.stderr,
            )
            return

        batch: List[logging.LogRecord] = []
        last_flush = time.monotonic()

        while not self._stop_event.is_set() or not self._queue.empty():
            try:
                record = self._queue.get(timeout=self._flush_interval)
            except queue.Empty:
                # Flush whatever we have on timeout
                if batch:
                    self._write_batch(batch)
                    batch = []
                    last_flush = time.monotonic()
                continue

            if record is None:
                # Sentinel → flush and exit
                break

            batch.append(record)

            elapsed = time.monotonic() - last_flush
            if len(batch) >= self._batch_size or elapsed >= self._flush_interval:
                self._write_batch(batch)
                batch = []
                last_flush = time.monotonic()

        # Final flush
        if batch:
            self._write_batch(batch)

    def _write_batch(self, batch: List[logging.LogRecord]) -> None:
        """Write a batch of records to the database with retry."""
        if self._db is None:
            return

        delay = self._retry_delay
        for attempt in range(self._retry_attempts):
            try:
                for record in batch:
                    self._write_single(record)
                # Ensure data is durable — db_accessor's relational
                # backends don't always auto-commit.
                try:
                    self._db.commit()
                except Exception:
                    pass
                return
            except Exception:
                if attempt < self._retry_attempts - 1:
                    time.sleep(delay)
                    delay *= 2
                    # Attempt reconnect
                    try:
                        self._connect()
                    except Exception:
                        pass
                else:
                    import sys
                    print(
                        f"[logger_pkg] ERROR: failed to write {len(batch)} log records "
                        f"to {self._db_type} after {self._retry_attempts} attempts",
                        file=sys.stderr,
                    )

    def _write_single(self, record: logging.LogRecord) -> None:
        """Persist a single record via db_accessor's CRUD API."""
        if self._db is None:
            return

        if self._db_type == "redis":
            import uuid
            doc = _record_to_mongo_doc(record)
            doc["id"] = str(uuid.uuid4())
            self._db.create(self._table, doc)
        elif self._is_nosql:
            doc = _record_to_mongo_doc(record)
            self._db.create(self._table, doc)
        else:
            data = _record_to_dict(record, self._table)
            self._db.create(self._table, data)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_database_handler(
    db_type: str,
    connection_details: Dict[str, Any],
    table: str = "log_records",
    queue_size: int = 10_000,
    batch_size: int = 100,
    flush_interval: float = 2.0,
    retry_attempts: int = 3,
    retry_delay: float = 0.5,
    level: int = logging.NOTSET,
    formatter: Optional[logging.Formatter] = None,
) -> DatabaseHandler:
    """Create a :class:`DatabaseHandler` with the given configuration.

    Args:
        db_type: Backend identifier (``"sqlite"``, ``"postgres"``, etc.).
        connection_details: Passed to ``db.connect()``.
        table: Target table / collection name.
        queue_size: In-memory buffer capacity.
        batch_size: Records per write batch.
        flush_interval: Max seconds between flush cycles.
        retry_attempts: Retries on write failure.
        retry_delay: Base retry delay (exponential backoff).
        level: Minimum level to persist.
        formatter: Optional formatter (used when records are formatted
                   before serialisation).

    Returns:
        A configured :class:`DatabaseHandler`.

    Raises:
        db_accessor.exceptions.ConfigurationError: If *db_type* is not
            installed.
    """
    installed = list_installed_databases()
    if db_type not in installed:
        from db_accessor.exceptions import ConfigurationError
        raise ConfigurationError(
            f"Database driver for {db_type!r} is not installed. "
            f"Installed backends: {installed}. "
            f"Install the driver with: pip install db-accessor[{db_type}]"
        )

    handler = DatabaseHandler(
        db_type=db_type,
        connection_details=connection_details,
        table=table,
        queue_size=queue_size,
        batch_size=batch_size,
        flush_interval=flush_interval,
        retry_attempts=retry_attempts,
        retry_delay=retry_delay,
        level=level,
    )

    if formatter:
        handler.setFormatter(formatter)

    return handler
