"""
Async-safe queue handler helpers.

Python's :class:`logging.handlers.QueueHandler` / :class:`logging.handlers.QueueListener`
pair decouples the calling thread from slow I/O handlers (file writes,
network calls).  The calling thread enqueues the record in microseconds;
a background thread dequeues and dispatches it to the real handlers.

This module provides:

* :class:`AsyncQueueHandler` — thin subclass that respects ``queue_size``
  and drops records (with a warning) instead of blocking when the queue is full.
* :func:`build_queue_pair` — convenience factory that wires up the handler
  and listener and starts the listener thread.

Usage::

    from logger_pkg.handlers.async_queue import build_queue_pair

    queue_handler, listener = build_queue_pair(
        handlers=[file_handler, console_handler],
        queue_size=10_000,
    )
    root_logger.addHandler(queue_handler)

    # On shutdown:
    listener.stop()
"""

from __future__ import annotations

import logging
import logging.handlers
import queue
from typing import List, Optional, Tuple


class AsyncQueueHandler(logging.handlers.QueueHandler):
    """A ``QueueHandler`` that never blocks the calling thread.

    When the queue is full (``maxsize > 0`` and the queue has reached
    capacity) the record is discarded and a single ``WARNING`` is emitted
    via ``sys.stderr`` (not through the logging system, to avoid recursion).

    Args:
        q: The :class:`queue.Queue` to put records into.
    """

    def enqueue(self, record: logging.LogRecord) -> None:
        try:
            self.queue.put_nowait(record)
        except queue.Full:
            import sys
            print(
                f"[logger_pkg] WARNING: log queue is full — dropping record: {record.getMessage()!r}",
                file=sys.stderr,
            )

    def prepare(self, record: logging.LogRecord) -> logging.LogRecord:
        # Keep exc_info so the listener thread can format it properly.
        # We do NOT call self.format() here (that happens in the listener).
        self.format(record)
        record.msg = record.message
        record.args = None
        record.exc_info = None
        record.exc_text = None
        return record


def build_queue_pair(
    handlers: List[logging.Handler],
    queue_size: int = 10_000,
    respect_handler_level: bool = True,
    auto_start: bool = True,
) -> Tuple[AsyncQueueHandler, logging.handlers.QueueListener]:
    """Create a ``(QueueHandler, QueueListener)`` pair and optionally start the listener.

    Args:
        handlers: The "real" handlers that receive log records on the
                  background thread.
        queue_size: Maximum number of records buffered in memory.
                    ``0`` means unbounded (use with care).
        respect_handler_level: Passed to ``QueueListener``; when ``True``
                               each handler's level is checked before
                               dispatching (standard behaviour).
        auto_start: If ``True`` (default) the listener is started immediately.

    Returns:
        A ``(AsyncQueueHandler, QueueListener)`` tuple.  Call
        ``listener.stop()`` during application shutdown to flush remaining
        records and join the background thread.
    """
    log_queue: queue.Queue[logging.LogRecord] = queue.Queue(maxsize=queue_size)

    queue_handler = AsyncQueueHandler(log_queue)

    listener = logging.handlers.QueueListener(
        log_queue,
        *handlers,
        respect_handler_level=respect_handler_level,
    )

    if auto_start:
        listener.start()

    return queue_handler, listener
