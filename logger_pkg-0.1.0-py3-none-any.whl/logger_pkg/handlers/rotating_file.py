"""
Rotating file handler wrappers with optional gzip compression.

Two factory functions are provided:

* :func:`build_rotating_file_handler` — size-based rotation
  (:class:`logging.handlers.RotatingFileHandler`).
* :func:`build_timed_rotating_file_handler` — time-based rotation
  (:class:`logging.handlers.TimedRotatingFileHandler`).

Both accept an optional ``gzip_rotated`` flag.  When enabled, each rotated
file is compressed in-place via a ``rotator`` hook on the handler, keeping
disk usage low without external cron jobs.

Usage::

    from logger_pkg.handlers.rotating_file import build_rotating_file_handler

    fh = build_rotating_file_handler(
        path="logs/app.log",
        max_bytes=10 * 1024 * 1024,  # 10 MB
        backup_count=5,
        gzip_rotated=True,
    )
"""

from __future__ import annotations

import gzip
import logging
import logging.handlers
import os
import shutil
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Gzip rotator helpers
# ---------------------------------------------------------------------------

def _gzip_rotator(source: str, dest: str) -> None:
    """Compress *source* to *dest* + ``.gz`` and remove *source*."""
    gz_dest = dest + ".gz"
    with open(source, "rb") as f_in, gzip.open(gz_dest, "wb") as f_out:
        shutil.copyfileobj(f_in, f_out)
    os.remove(source)


def _gzip_namer(default_name: str) -> str:
    """Return the rotated filename; we add ``.gz`` extension later in rotator."""
    return default_name


# ---------------------------------------------------------------------------
# Size-based rotation
# ---------------------------------------------------------------------------

def build_rotating_file_handler(
    path: str | Path,
    max_bytes: int = 10 * 1024 * 1024,
    backup_count: int = 5,
    encoding: str = "utf-8",
    gzip_rotated: bool = True,
    level: int = logging.NOTSET,
    formatter: Optional[logging.Formatter] = None,
) -> logging.handlers.RotatingFileHandler:
    """Create a size-based rotating file handler.

    Args:
        path: Path to the log file (parent directories are created if needed).
        max_bytes: Maximum file size before rotation.  ``0`` disables rotation.
        backup_count: Number of backup files to keep.
        encoding: File encoding (default ``"utf-8"``).
        gzip_rotated: If ``True``, rotated files are compressed with gzip.
        level: Handler log level (default ``logging.NOTSET`` — all records).
        formatter: Formatter instance to attach.

    Returns:
        A configured :class:`~logging.handlers.RotatingFileHandler`.
    """
    Path(path).parent.mkdir(parents=True, exist_ok=True)

    handler = logging.handlers.RotatingFileHandler(
        filename=str(path),
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding=encoding,
        delay=True,
    )
    handler.setLevel(level)

    if formatter:
        handler.setFormatter(formatter)

    if gzip_rotated and backup_count > 0:
        handler.rotator = _gzip_rotator
        handler.namer = _gzip_namer

    return handler


# ---------------------------------------------------------------------------
# Time-based rotation
# ---------------------------------------------------------------------------

def build_timed_rotating_file_handler(
    path: str | Path,
    when: str = "midnight",
    interval: int = 1,
    backup_count: int = 7,
    encoding: str = "utf-8",
    utc: bool = True,
    gzip_rotated: bool = True,
    level: int = logging.NOTSET,
    formatter: Optional[logging.Formatter] = None,
) -> logging.handlers.TimedRotatingFileHandler:
    """Create a time-based rotating file handler.

    Args:
        path: Path to the log file (parent directories are created if needed).
        when: Rotation schedule — ``'S'``, ``'M'``, ``'H'``, ``'D'``,
              ``'W0'``–``'W6'``, or ``'midnight'``.
        interval: How many *when* units between rotations.
        backup_count: Number of backup files to keep.
        encoding: File encoding.
        utc: Use UTC for rotation time calculation (recommended).
        gzip_rotated: If ``True``, rotated files are compressed with gzip.
        level: Handler log level.
        formatter: Formatter instance to attach.

    Returns:
        A configured :class:`~logging.handlers.TimedRotatingFileHandler`.
    """
    Path(path).parent.mkdir(parents=True, exist_ok=True)

    handler = logging.handlers.TimedRotatingFileHandler(
        filename=str(path),
        when=when,
        interval=interval,
        backupCount=backup_count,
        encoding=encoding,
        utc=utc,
        delay=True,
    )
    handler.setLevel(level)

    if formatter:
        handler.setFormatter(formatter)

    if gzip_rotated and backup_count > 0:
        handler.rotator = _gzip_rotator
        handler.namer = _gzip_namer

    return handler
